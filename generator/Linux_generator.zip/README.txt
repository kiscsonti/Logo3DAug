start.sh - vxfb-vel elindítja a progit, nálam megy vele rendesen
expected_Player.log - ezt a logot köpi ki nálam, nem feltétlen kell ilyennek lennie, de ez biztos, hogy helyes
open_Player.log.sh - megnyitja nano-val az aktuális Player.log-ot, hogy le lehessen ellenõrizni

a képek az ./output mappában jelennek meg